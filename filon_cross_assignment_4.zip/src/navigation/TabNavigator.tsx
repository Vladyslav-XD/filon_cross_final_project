import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StackNavigator } from './StackNavigator';
import { FavouritesScreen } from '../screens/FavouritesScreen';
import { RandomScreen } from '../screens/RandomScreen';
import { SCREENS } from '../constants/screens';
import { colors } from '../theme/colors';
import { HomeIcon, HeartIcon, ShuffleIcon } from '../components/icons';

const Tab = createBottomTabNavigator();

export const TabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: {
          backgroundColor: '#ffffff',
          borderTopWidth: 1,
          borderTopColor: colors.badgeBorder,
          height: 80,
          paddingHorizontal: 20,
        },
        tabBarActiveTintColor: colors.mainBtn,
        tabBarInactiveTintColor: colors.iconBG,
      }}
    >
      <Tab.Screen 
        name={SCREENS.HOME_TAB} 
        component={StackNavigator}
        options={{
          tabBarIcon: ({ color, focused }) => (
            <HomeIcon size={24} color={color} focused={focused} />
          )
        }}
      />
      <Tab.Screen 
        name={SCREENS.FAVOURITES_TAB} 
        component={FavouritesScreen} 
        options={{
          tabBarIcon: ({ color, focused }) => (
            <HeartIcon size={24} color={color} focused={focused} />
          )
        }}
      />
      <Tab.Screen 
        name={SCREENS.RANDOM_TAB} 
        component={RandomScreen} 
        options={{
          tabBarIcon: ({ color, focused }) => (
            <ShuffleIcon size={24} color={color} focused={focused} />
          )
        }}
      />
    </Tab.Navigator>
  );
};
